﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

/// <summary>
/// Descripción breve de AuthenticationHeader
/// </summary>

    [DataContract]
    public sealed class AuthenticationHeader //: SoapHeader
    {
        private string m_username;
        private DateTime m_dateTime;
        private string m_hash;

        /// <summary>
        /// The username used for authentication
        /// </summary>
        [DataMember]
        public string Username
        {
            get { return m_username; }
            set { m_username = value; }
        }

        /// <summary>
        /// The current time
        /// </summary>
        [DataMember]
        public DateTime DateTime
        {
            get { return m_dateTime; }
            set { m_dateTime = value; }
        }

        /// <summary>
        /// A SHA1 hash made from Username|Password|DateTime
        /// </summary>
        [DataMember]
        public string Hash
        {
            get { return m_hash; }
            set { m_hash = value; }
        }
    }