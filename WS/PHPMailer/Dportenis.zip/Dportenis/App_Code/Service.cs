﻿using System;
using System.Text;
using System.Web.Services;
using System.Web.Services.Protocols;

[WebService(Namespace = "http://www.arafacturacion.com/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// Para permitir que se llame a este servicio web desde un script, usando ASP.NET AJAX, quite la marca de comentario de la línea siguiente. 
// [System.Web.Script.Services.ScriptService]
public class Service : System.Web.Services.WebService
{
    public AuthHeader Authentication = new AuthHeader();
    public Service () {
        //Elimine la marca de comentario de la línea siguiente si utiliza los componentes diseñados 
        //InitializeComponent();
        //ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls;
        /*
        XmlSchemaSet schemaSet = new XmlSchemaSet();
        schemaSet.ValidationEventHandler += new ValidationEventHandler(ValidationCallback);
        schemaSet.Add("http://www.arafacturacion.com/", "Service.asmx?WSDL");
        schemaSet.Compile();

        // Retrieve the compiled XmlSchema objects for the customer and
        // address schema from the XmlSchemaSet by iterating over 
        // the Schemas property.
        XmlSchema customerSchema = null;
        foreach (XmlSchema schema in schemaSet.Schemas())
        {
            if (schema.TargetNamespace == "http://www.arafacturacion.com/")
                customerSchema = schema;
        }

        // Reprocess and compile the modified XmlSchema object 
        // of the customer schema and write it to the console.    
        schemaSet.Reprocess(customerSchema);
        schemaSet.Compile();
        customerSchema.Write(Console.Out);

        // Recursively write all of the schemas imported into the
        // customer schema to the console using the Includes 
        // property of the customer schema.
        RecurseExternals(customerSchema); 
        */
    }

    [SoapHeader("Authentication", Required = true)]
    [WebMethod]
    public string ObtieneFacturas(string rfc)
    {
        ARAFActuracion3._2.ARA_Facturacion facturacion = new ARAFActuracion3._2.ARA_Facturacion();
        facturacion.GetCompanies(rfc);
        return "Ok1";
    }

    [SoapHeader("Authentication", Required = true)]
    [WebMethod]
    public string Facturacion(string xml, string produccion, string username, string password)
    {
        //Logger.addLogEntry("aocegueda : " + xml + "\n\r");
        //Logger.addLogEntry("Produccion : " + produccion + "\n\r");
        /*Logger.addLogEntry("Produccion : " + produccion);
        Logger.addLogEntry("Usuario : " + username);
        Logger.addLogEntry("Password : " + password);*/
        //Logger.addLogEntry("Inicio Timbrado: " + DateTime.Now);
        bool bProduccion = true;
        //0 Prueba
        //1 Produccion
        if (produccion.CompareTo("1") == 0)
            bProduccion = true;
        else
            bProduccion = false;

        string errorMessage = string.Empty;
        int errorCode = -1;
        string cadenaOriginal = string.Empty;
        ARAFActuracion3._2.ARA_Facturacion facturacion = new ARAFActuracion3._2.ARA_Facturacion();
        if (bProduccion)
        {
            //facturacion.setUserPAC("PRUEBAS_DP");
            //facturacion.setPasswordPAC("DP123");
        }
        byte[] data = Convert.FromBase64String(xml);
        string decodedString = Encoding.UTF8.GetString(data);
        string strCFDI = facturacion.FacturaPublicoGeneral(decodedString, ref errorMessage, ref errorCode, bProduccion);
        if (errorMessage.Length > 0)
        {
            Logger.addLogEntry("Error : " + errorMessage + "\n\r");
            Logger.addLogEntry("XML Error: " + xml + "\n\r");
            return @"<?xml version='1.0'?> <error> " + errorMessage + " </error> </xml>";
        }

        byte[] toEncodeAsBytes = System.Text.ASCIIEncoding.ASCII.GetBytes(strCFDI);
        strCFDI = System.Convert.ToBase64String(toEncodeAsBytes);
        return @"<?xml version='1.0'?> <xmlBase64> " + strCFDI + " </xmlBase64> </xml>";           
    }

    [SoapHeader("Authentication", Required = true)]
    [WebMethod]
    public string FacturacionCliente(string xml, string produccion, string ticket)
    {
        //Logger.addLogEntry("XML : " + xml);
        bool bProduccion = true;
        //0 Prueba
        //1 Produccion
        if (produccion.CompareTo("1") == 0)
            bProduccion = true;
        else
            bProduccion = false;

        string errorMessage = string.Empty;
        int errorCode = -1;
        string cadenaOriginal = string.Empty;
        ARAFActuracion3._2.ARA_Facturacion facturacion = new ARAFActuracion3._2.ARA_Facturacion();
        if (bProduccion)
        {
            //facturacion.setUserPAC("PRUEBAS_DP");
            //facturacion.setPasswordPAC("DP123");
        }
        byte[] data = Convert.FromBase64String(xml);
        string decodedString = Encoding.UTF8.GetString(data);
        string strCFDI = facturacion.FacturaCliente(decodedString, ref errorMessage, ref errorCode, bProduccion, ticket);
        if (errorMessage.Length > 0)
        {
            Logger.addLogEntry("Error : " + errorMessage + "\n\r");
            Logger.addLogEntry("XML Error : " + xml + "\n\r");
            return @"<?xml version='1.0'?> <error> " + errorMessage + " </error> </xml>";
        }
        byte[] toEncodeAsBytes = System.Text.ASCIIEncoding.ASCII.GetBytes(strCFDI);
        strCFDI = System.Convert.ToBase64String(toEncodeAsBytes);
        return @"<?xml version='1.0'?> <xmlBase64> " + strCFDI + " </xmlBase64> </xml>";
    }

    [SoapHeader("Authentication", Required = true)]
    [WebMethod]
    public string FacturacionClienteEgreso(string xml, string produccion, string ticket)
    {
        //Logger.addLogEntry("XML : " + xml);
        bool bProduccion = true;
        //0 Prueba
        //1 Produccion
        if (produccion.CompareTo("1") == 0)
            bProduccion = true;
        else
            bProduccion = false;

        string errorMessage = string.Empty;
        int errorCode = -1;
        string cadenaOriginal = string.Empty;
        ARAFActuracion3._2.ARA_Facturacion facturacion = new ARAFActuracion3._2.ARA_Facturacion();
        if (bProduccion)
        {
            //facturacion.setUserPAC("PRUEBAS_DP");
            //facturacion.setPasswordPAC("DP123");
        }
        byte[] data = Convert.FromBase64String(xml);
        string decodedString = Encoding.UTF8.GetString(data);
        string strCFDI = facturacion.FacturaClienteEgreso(decodedString, ref errorMessage, ref errorCode, bProduccion, ticket);
        if (errorMessage.Length > 0)
        {
            Logger.addLogEntry("Error : " + errorMessage + "\n\r");
            Logger.addLogEntry("XML Error : " + xml + "\n\r");
            return @"<?xml version='1.0'?> <error> " + errorMessage + " </error> </xml>";
        }
        byte[] toEncodeAsBytes = System.Text.ASCIIEncoding.ASCII.GetBytes(strCFDI);
        strCFDI = System.Convert.ToBase64String(toEncodeAsBytes);
        return @"<?xml version='1.0'?> <xmlBase64> " + strCFDI + " </xmlBase64> </xml>";
    }

    

    public class AuthHeader : SoapHeader
    {
        public string Username;
        public string Password;
    }

    [SoapHeader("Authentication", Required = true)]
    [WebMethod]
    public string CancelarFactura(string strUUID, string strRFC, string xml, string strTicket, bool bProduccion)
    {
        Logger.addLogEntry("XML : " + xml);
        Logger.addLogEntry("Ticket : " + strTicket);
        Logger.addLogEntry("RFC : " + strRFC);
        Logger.addLogEntry("UUID : " + strUUID);

        int errorCode = -1;
        string errorMessage = string.Empty;
        ARAFActuracion3._2.ARA_Facturacion cancelacion = new ARAFActuracion3._2.ARA_Facturacion();
        byte[] data = Convert.FromBase64String(xml);
        string decodedString = Encoding.UTF8.GetString(data);
        //string strCFDI = cancelacion.CancelaFacturaPublicoGeneral(strRFC, strUUID, ref errorMessage, ref errorCode);
        return cancelacion.CancelaFacturaPublicoGeneral(decodedString, strUUID, ref errorMessage, ref errorCode, bProduccion, strTicket);
    }

    [SoapHeader("Authentication", Required = true)]
    [WebMethod]
    public string CancelarFacturaPortal(string strUUID, string strRFC, bool bProduccion)
    {
        int errorCode = -1;
        string errorMessage = string.Empty;
        ARAFActuracion3._2.ARA_Facturacion cancelacion = new ARAFActuracion3._2.ARA_Facturacion();
        string strRespuesta = cancelacion.CancelaFacturaPortal(strRFC, strUUID.Trim(), ref errorMessage, ref errorCode, bProduccion);
        Logger.addLogEntry("Factura Cancelada : " + strRespuesta + " UUID : " + strUUID + "\n\r");
        return strRespuesta;

        //return "Termino Cancelo : " + n;
        //return cancelacion.CancelaFacturaPortal(strRFC, strUUID, ref errorMessage, ref errorCode, bProduccion);
    }
}