﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Descripción breve de Parametro
/// </summary>
public class Parametro
{
	public Parametro()
	{
		//
		// TODO: Agregar aquí la lógica del constructor
		//
	}
}