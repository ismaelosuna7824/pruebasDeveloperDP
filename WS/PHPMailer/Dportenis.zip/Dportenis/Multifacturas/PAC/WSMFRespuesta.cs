﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Descripción breve de WSMFRespuesta
/// </summary>
public class WSMFRespuesta
{
	public WSMFRespuesta()
	{
		//
		// TODO: Agregar aquí la lógica del constructor
		//
	}
}